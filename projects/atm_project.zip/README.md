# ATM System

## Description
This is a simple ATM system built using Python with Flask. It allows users to check their balance, withdraw, and deposit money.

## Installation Instructions
1. Clone the repository:
   ```bash
   git clone https://github.com/Ramyapallelamudi/Atm_System.git
