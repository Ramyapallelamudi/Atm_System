// Function to handle pin entry
function submitPin() {
    let pin = document.getElementById('pin-input').value;
    sendRequest('balance', pin);
}

// Function to check balance
function checkBalance() {
    let pin = document.getElementById('pin-input').value;
    sendRequest('balance', pin);
}

// Function to handle withdrawal
function withdraw() {
    let pin = document.getElementById('pin-input').value;
    let amount = prompt("Enter amount to withdraw");
    sendRequest('withdraw', pin, parseInt(amount));
}

// Function to handle deposit
function deposit() {
    let pin = document.getElementById('pin-input').value;
    let amount = prompt("Enter amount to deposit");
    sendRequest('deposit', pin, parseInt(amount));
}

// Function to exit ATM
function exitATM() {
    document.getElementById('message').innerText = "Please Insert your Card";
    document.getElementById('atm-options').style.display = "none";
    document.getElementById('atm-screen').style.display = "block";
    document.getElementById('pin-input').value = "";
}

// Helper function to send requests to the Python backend
function sendRequest(action, pin, amount = 0) {
    fetch('/atm', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ action, pin: parseInt(pin), amount })
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            document.getElementById('result').innerText = data.message;
            document.getElementById('atm-options').style.display = "block";
            document.getElementById('atm-screen').style.display = "none";
        } else {
            document.getElementById('result').innerText = data.message;
        }
    })
    .catch(error => console.error('Error:', error));
}
