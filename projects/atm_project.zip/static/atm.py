from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

# Initial balance and pin setup
balance = 1000
correct_pin = 2003

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/atm', methods=['POST'])
def atm():
    global balance
    action = request.json.get('action')
    pin = request.json.get('pin')
    amount = request.json.get('amount', 0)
    
    # Validate PIN
    if pin != correct_pin:
        return jsonify({'message': 'Invalid PIN', 'status': 'error'})

    if action == 'balance':
        return jsonify({'message': f'Your current balance is ${balance}', 'status': 'success'})

    elif action == 'withdraw':
        if amount > balance:
            return jsonify({'message': 'Insufficient funds', 'status': 'error'})
        balance -= amount
        return jsonify({'message': f'${amount} withdrawn. New balance: ${balance}', 'status': 'success'})

    elif action == 'deposit':
        balance += amount
        return jsonify({'message': f'${amount} deposited. New balance: ${balance}', 'status': 'success'})

    return jsonify({'message': 'Invalid action', 'status': 'error'})

if __name__ == '__main__':
    app.run(debug=True)
